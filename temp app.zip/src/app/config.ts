declare const CONFIG: {
  env: string;
  apiEndpoint: string;
  appDataEndpoint: string;
  sentryDSN: string;
  sentryENV: string;
  baseUrl: string;
};
export default CONFIG;
