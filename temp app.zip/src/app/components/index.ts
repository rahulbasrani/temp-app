export { default as SignupComponent } from "./signup/signup.component";
export { default as AppComponent } from "./app/app.component";
export { default as EmailVerificationComponent } from "./email-verification/email-verification.component";
