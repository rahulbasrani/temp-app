import { RegistrationForm } from "@models";

export interface UserProps {
  registerFormState: RegistrationForm;
}
