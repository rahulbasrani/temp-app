import * as React from "react";
import { ComponentViewState, DIContext } from "@helpers";
import "../signup/signup.style.css";
import { useHistory } from "react-router";
import Footer from "../footer/footer.component";
import Navbar from "../navbar/navbar.component";
const HeroMessage = require("../../../assets/images/hero-message.svg") as string;

const EmailVerificationComponent: React.FC = () => {
  const dependencies = React.useContext(DIContext);
  const history = useHistory();
  const [email, setEmail] = React.useState(null);
  const { translation, resendEmailVerifcationService } = dependencies;
  const [
    componentState,
    setComponentState,
  ] = React.useState<ComponentViewState>(ComponentViewState.DEFAULT);
  const isError = componentState === ComponentViewState.ERROR;

  React.useEffect(() => {
    const data = localStorage.getItem("email");
    if (data) {
      setEmail(JSON.parse(data));
    }
  }, []);

  const resendChange = async () => {
    try {
      const response = await resendEmailVerifcationService.resendEmail(email);
      if (response.data) {
        setComponentState(ComponentViewState.LOADED);
      } else {
        setComponentState(ComponentViewState.ERROR);
      }
    } catch (error) {
      throw new Error(error);
    }
  };

  const logoutEmail = () => {
    history.push("/signup");
  };

  //            ***************   Form Element     ***************           //
  return (
    <div className="signup-body">
      <Navbar />
      <div className="main-content">
        <div className="container-fluid">
          <div className="img-div col-md-6">
            <div className="col-md-8  mx-auto text-left">
              <img src={HeroMessage} alt="" />
            </div>
          </div>

          <section className=" email-verification-section col-md-6">
            <div className="container-fluid">
              <div className="col-md-9 col-12">
                <h1 className="form-title col-md-12 mb-3">
                  {translation.t("VERIFY_YOUR_EMAIL")}
                </h1>
                <div className="text-left verification-class col-md-12">
                  <span>{translation.t("VERIFICATION_EMAIL_SENT")}</span>
                  <span className="font-weight-bold">{`${email}`}</span>
                  <span>{translation.t("CHECK_INBOX")}</span>
                </div>
                <div className=" email-verification-button col-md-12">
                  <button
                    type="submit"
                    name="logout"
                    onClick={logoutEmail}
                    id="logout"
                    className="btn btn-lg btn-block btn-class signup-btn"
                  >
                    <span className="button-text ">
                      {translation.t("LOGOUT")}
                    </span>
                    <span className="arrow "></span>
                  </button>
                </div>

                <div className="text-left col-md-12">
                  <span className="checkbox-label-text ">
                    <span className="text-left verification-class gray-class">
                      {translation.t("EMAIL_VERIFICATION")}
                    </span>
                    <span>
                      <a href="/tnc" className="anchor-class"></a>
                    </span>
                    &nbsp;
                    <span>
                      <a
                        onClick={resendChange}
                        className="anchor-class-verification text-decoration-none"
                      >
                        {translation.t("CLICK_RESEND")}
                      </a>
                      .
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default EmailVerificationComponent;
